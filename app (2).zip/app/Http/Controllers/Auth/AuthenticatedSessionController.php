<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use App\Providers\RouteServiceProvider;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class AuthenticatedSessionController extends Controller
{
    /**
     * Display the login view.
     */
    public function create(): View
    {
        return view('auth.login');
    }

    /**
     * Handle an incoming authentication request.
     */
    public function store(Request $request): RedirectResponse
    {

        $credentials = $request->only('username','password');

        if(!Auth::attempt($credentials)){
            $request->session()->regenerate();

            $notification = [
                'message' => 'Invalid username or password',
                'alert-type' => 'error'
            ];
            return redirect()->back()->withInput()->with($notification);

        }
        // $request->authenticate();

        $request->session()->regenerate();

$notification = [
    'message' => 'User Login Successfully',
    'alert-type' => 'success'
];
return redirect()->intended(RouteServiceProvider::HOME)->with($notification);

    }

    /**
     * Destroy an authenticated session.
     */
    public function destroy(Request $request): RedirectResponse
    {
        Auth::guard('web')->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('/');
    }
}
