<?php

namespace App\Http\Controllers\Dealer;

use App\Http\Controllers\Controller;
use App\Models\EWallet;
use Illuminate\Http\Request;

use App\Models\EWalletTransaction;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class EWalletController extends Controller
{

    public function MyEWallet(Request $request){
        $breadcrumbData = [
            ['label' => 'HC Gaming', 'url' => route('all.statistics')],

            ['label' => 'My E-Wallet', 'url' => route('My.Wallet')],
        ];

        $id = Auth::user()->id;
        $ewalletData = EWallet::where('user_id',$id)->latest()->get();
        // Total number of wallet transactions
 // Total amount for all transactions


     // Retrieve the user's e-wallet balance with status 1 (total income)
$totalIncome = EWalletTransaction::where('user_id', $id)
->where('type', 'credit') // Consider only income (credits)
->sum('amount');

// Retrieve the user's e-wallet balance with status 1 (total expenses)
$totalExpenses = EWalletTransaction::where('user_id', $id)
->where('type', 'debit') // Consider only expenses (debits)
->sum('amount');

// Calculate the current balance
$currentBalance = $totalIncome - $totalExpenses;


 $totalAmount = $currentBalance;

  // Total amount for processing transactions (status = 0)
  $processingTotal = EWallet::where('user_id', $id)->where('status', 0)->sum('amount');

        // Total amount for approved transactions (status = 1)
        $approvedTotal = EWallet::where('user_id', $id)->where('status', 1)->sum('amount');



        // return view('agent.ewallet.mywallet.all',compact('breadcrumbData'));
        return view('agent.ewallet.mywallet_all', compact('totalAmount', 'processingTotal', 'approvedTotal', 'ewalletData', 'breadcrumbData'));


}
public function TopUpWallet(){
    return view('agent.ewallet.mywallet_topup_add');

}//End Method
public function StoreWallet(Request $request){
    //validate the incoming request data
    $request->validate([
        'amount'=>'required|numeric|min:0',
       'receipt'=>'required|image|mimes:jpeg,png,jpg|max:2048',//Assuming want to upload as image

    ],[
        'amount.required' => 'Amount is required',
        'amount.numeric'=>'Amount must be a number',
        'amount.min' =>'Amount muist be at least 1',
        'receipt.required'=> 'Payment proof is required',

    ]);
    //Hande payment proof upload
    $image = $request->file('receipt');
    $name_gen = hexdec(uniqid()) . '.' . $image->getClientOriginalExtension();
    $image->move(('upload/ewallet'),$name_gen);
    $receipt='upload/ewallet/'. $name_gen;

    //Additional logic for savings the top-up transaction to the database

        // For example, you can save the user ID, top-up amount, payment proof URL, timestamp, etc.
        // You can customize this part based on your database structure and requirements
EWallet::create([
'user_id' =>Auth::id(),
'amount' => $request->amount,
'receipt' =>$receipt,
'created_at'=> Carbon::now(),
]);


$notification = [
    'message' =>'E-Wallet Top Up Request submitted Successfully',
    'alert-type' => 'success',
];
return redirect()->route('My.Wallet')->with($notification);
}

public function AllDealerWallets(){

    $breadcrumbData=[
        ['label' => 'HC Gaming', 'url' => route('all.statistics')],
        ['label' => 'Dealer E-Wallet Request', 'url' => route('all.dealer.wallets')],

    ];
    $ewalletrequest = Ewallet::latest()->get();
    //Wallet Request No
    $WalletRequestCount = EWallet::where('status','0')->count();
 // Total amount for all transactions
 $totalAmount = EWallet::where('status', '!=', -1)->sum('amount');
 // Total amount for processing transactions (status = 0)
  $processingTotal = EWallet::where('status', 0)->sum('amount');
  $ApprovedTotal = EWallet::where('status',1)->sum('amount');
  return view('admin.finance.financial_all',compact('ewalletrequest','WalletRequestCount','processingTotal','ApprovedTotal','breadcrumbData'));


}

public function UpdateDealerWalletsApprovedStatus($id,Request $request){
    //find the or
    $walletrequest = EWallet::find($id);
    if(!$walletrequest){
        return redirect()->with('error','Wallet Request Not Found');

    }

    //update the request to "apprtoved
    $walletrequest->status='1';
    $walletrequest->save();

    // Create a new e-wallet transaction to record the top-up
    EWalletTransaction::create([
        'user_id' => $walletrequest->user_id,
        'amount' => $walletrequest->amount,
        'type' => 'credit', // Indicate it as a credit or top-up transaction
        'remarks' => 'E-Wallet Top Up Request Approved', // Add remarks indicating approval
    ]);
    $notification = [
        'message' => 'Wallet Request has been updated successfully',
        'alert-type' => 'success'
    ];
    //check if the request status is confirmed before inserting t
 // Save the top-up transaction to the database

   // Redirect back with a success message
   return redirect()->back()->with($notification);
}


public function UpdateDealerWalletsRejectStatus($id){
    //find the or
    $walletrequest = EWallet::find($id);
    if(!$walletrequest){
        return redirect()->with('error','Wallet Request Not Found');

    }

    //update the request to "apprtoved
    $walletrequest->status='-1';
    $walletrequest->save();

    $notification = [
        'message' => 'Wallet Request has been rejected successfully',
        'alert-type' => 'success'
    ];
    //check if the request status is confirmed before inserting t

   // Redirect back with a success message
   return redirect()->back()->with($notification);
}

public function MyWalletHistory(Request $request){


    $breadcrumbData = [
        ['label' => 'HC Gaming', 'url' => route('all.statistics')],

        ['label' => 'My E-Wallet History', 'url' => route('My.Wallet.History')],
    ];

    $id = Auth::user()->id;


    // Retrieve the user's e-wallet balance with status 1 (total income)
$totalIncome = EWalletTransaction::where('user_id', $id)
->where('type', 'credit') // Consider only income (credits)
->sum('amount');

// Retrieve the user's e-wallet balance with status 1 (total expenses)
$totalExpenses = EWalletTransaction::where('user_id', $id)
->where('type', 'debit') // Consider only expenses (debits)
->sum('amount');

// Calculate the current balance
$currentBalance = $totalIncome - $totalExpenses;


    $walletHistoryData = EWalletTransaction::where('user_id',$id)->latest()->get();
    // Calculate total amount in e-wallet excluding processing and reject statuses
    $totalAmount = EWallet::where('user_id', $id)
        ->where('status', '!=', -1) // Exclude reject status
        ->where('status', '!=', 0) // Exclude processing status
        ->sum('amount');
  // Calculate total amount of credit and debit
  $totalCreditAmount = $walletHistoryData->where('type', 'credit')->sum('amount');
  $totalDebitAmount = $walletHistoryData->where('type', 'debit')->sum('amount');

  return view('agent.ewallet.wallet_history_all', compact('currentBalance','walletHistoryData', 'breadcrumbData','totalAmount', 'totalCreditAmount', 'totalDebitAmount'));

}
}
