<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Acknowledgement extends Model
{
    use HasFactory;
    protected $table = 'acknowledgement';

    protected $fillable = ['title', 'long_description'];
}
