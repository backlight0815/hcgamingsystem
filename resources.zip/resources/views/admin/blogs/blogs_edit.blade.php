@extends('admin.admin_master')
@section('admin')

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>

<style type="text/css">
    .bootstrap-tagsinput .tag{
        margin-right: 2px;
        color: #b70000;
        font-weight: 700px;
    }
</style>

<title>Blog Management - Edit | HC Gaming Studio</title>

<div class="page-content">
    <div class="container-fluid">

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <h4 class="card-title">Add Blog Page</h4>






<form method="POST" action="{{ route('update.blog') }}" enctype="multipart/form-data">
    
    @csrf
<input type="hidden" name="id" value="{{ $blogs->id }}">
                        <div class="row mb-3">
                            <label for="example-text-input" class="col-sm-2 col-form-label">Blog Category Name</label>
                        <div class="col-sm-10">

                            <select name="blog_category_id" class="form-select" aria-label="Default select example">
                                <option selected disabled>--Open this select menu--</option>
                                @foreach($categories as $cat)
                                    @if(!$cat->trashed())
                                        <option value="{{ $cat->id }}" {{ $cat->id == $blogs->blog_category_id ? 'selected' : '' }}>
                                            {{ $cat->blog_category }}
                                        </option>
                                    @endif
                                @endforeach
                            </select>
                        @error('blog_category_id')
                        <div class="text-danger">{{ $message }}</div>
                    @enderror
                        </div>

                        </div>
                        <!-- end row -->

                        <div class="row mb-3">
                            <label for="example-text-input" class="col-sm-2 col-form-label">Blog Title</label>
                            <div class="col-sm-10">
                                <input name="blog_title"  class="form-control" value="{{ $blogs->blog_title }}" type="text"  id="example-text-input" >
                                @error('blog_title')
                                <div class="text-danger">{{ $message }}</div>
                            @enderror

                            </div>

                        </div>
                        <!-- end row -->



                        <div class="row mb-3">
                            <label for="example-text-input" class="col-sm-2 col-form-label">Blog Tags</label>
                            <div class="col-sm-10">
                                <input name="blog_tags" class="form-control" type="text"  data-role="tagsinput" value="{{ $blogs->blog_tags }}">

                                @error('blog_tags')
                                <div class="text-danger">{{ $message }}</div>
                            @enderror
                            </div>

                        </div>
                        <!-- end row -->




                        <div class="row mb-3">
                            <label for="example-text-input" class="col-sm-2 col-form-label">Blog Description</label>
                            <div class="col-sm-10">
                                <textarea id="elm1" name="blog_description">

                                    {{ $blogs->blog_description }}

                                </textarea>
                                @error('blog_description')
                                <div class="text-danger">{{ $message }}</div>
                            @enderror
                            </div>

                        </div>



                   <!-- end row -->

                   <div class="row mb-3">
                    <label for="example-text-input" class="col-sm-2 col-form-label">Blog Image</label>
                    <div class="col-sm-10">
                        <input name="blog_image" class="form-control" type="file"  id="image" accept="image/*">
                        @error('blog_image')
                        <div class="text-danger">{{ $message }}</div>
                    @enderror
                    </div>

                </div>
                <!-- end row -->


                        <!-- end row -->

                        <div class="row mb-3">

                            <label for="example-text-input" class="col-sm-2 col-form-label"></label>
                            <div class="col-sm-10">
                                <img id="showImages" class="rounded avatar-lg" src="{{ asset($blogs->blog_image) }}" alt="Card image cap">
                            </div>
                        </div>
                        <!-- end row -->
<input type="submit" class="btn btn-info waves-effect waves-light" value="Update  Blog Data">
</form>

                    </div>
                </div>
            </div> <!-- end col -->
        </div>
    </div>
</div>

<script type="text/javascript">

$(document).ready(function(){
    $('#image').change(function(e){
        var reader = new FileReader();
        reader.onload = function(e){
            $('#showImages').attr('src',e.target.result);
        }
        reader.readAsDataURL(e.target.files['0']);
    });
});


function redirectToPage() {
        window.location.href = "{{ route('add.blog') }}";
    }
</script>
@endsection
