@extends('admin.admin_master')
@section('admin')
<head>
    <!-- Add the Bootstrap CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">

</head>
<div class="page-content">
<div class="container-fluid">
<title>User Enquiry |HC Gaming</title>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">All the enquiry data</h4>



        </div>
    </div>
</div>
<!-- end page title -->
<div class="breadcrumb">
    @foreach ($breadcrumbData as $breadcrumb)
        <a href="{{ $breadcrumb['url'] }}">{{ $breadcrumb['label'] }}</a>
        @if (!$loop->last)
            <span> / </span>
        @endif
    @endforeach
</div>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <h4 class="card-title">All Message </h4>


                <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                    <thead>
                    <tr>
                        <th>SI</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Subject</th>
                        <th>Message</th>

                        <th>Date</th>

                        {{-- <th>Action</th> --}}
                    </tr>
                    </thead>


                    <tbody>
                        @php($i=1)
                        @foreach($contacts as $item)
                    <tr>
                        <td>{{ $i++ }}</td>
                        <td>{{ $item->name }} </td>
                        <td>{{ $item->email }} </td>
                        <td>{{ $item->phone }} </td>
                        <td>{{ $item->subject }} </td>
                        <td>{{ $item->message }} </td>

                        <td>{{ Carbon\Carbon::parse($item->created_at)->diffForHumans() }} </td>


                        {{-- <td> --}}
{{-- <a href="{{ route('delete.message',$item->id) }}" class="btn btn-danger sm" title="Delete Data" id="delete"><i class="fas fa-trash-alt"></i>   </a> --}}


                        {{-- </td> --}}

                    </tr>
@endforeach
                    </tbody>
                </table>

            </div>
        </div>
    </div> <!-- end col -->
</div> <!-- end row -->

</div> <!-- container-fluid -->
</div>

@endsection
