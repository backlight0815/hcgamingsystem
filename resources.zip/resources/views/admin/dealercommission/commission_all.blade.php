@extends('admin.admin_master')
@section('admin')
<script src="assets/libs/pdfmake/build/pdfmake.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.min.css">
<title>Dealer Commission | HC Gaming Studio</title>
<head>

   <!-- DataTables CSS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.6/css/jquery.dataTables.min.css">

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.11.6/js/jquery.dataTables.min.js"></script>

<title>HC Gaming | Dealer Commission</title>

</head>
<style>
    @media screen and (max-width: 768px) {
        .table-responsive {
            overflow-x: auto;
        }
    }
    </style>
<div class="page-content">
    <div class="container-fluid">
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0">Dealer Commission</h4>
                </div>
            </div>
        </div>
        <!-- end page title -->
        <div class="breadcrumb">
            @foreach ($breadcrumbData as $breadcrumb)
                <a href="{{ $breadcrumb['url'] }}">{{ $breadcrumb['label'] }}</a>
                @if (!$loop->last)
                    <span> / </span>
                @endif
            @endforeach
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        {{-- <h4 class="card-title mb-2">Shipping Order Data</h4> --}}
                        <div class="row text-center " >
                             <div class="row">

                                <div class="col-md-4 col-sm-6 border border-dark pt-3 mb-3">
                                    <h5 class="mb-0">{{ $totalCommission }} pts</h5>

                                    <p class="text-muted text-truncate">Total Commission Amount </p>
                                </div>



                            </div>
                        </div>
                                                <div class="table-responsive">

                        <table id="walletrequest" class="table table-bordered" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                                <tr>
                                    <th>SI</th>
                                    <th>UserID</th>
                                    <th>Username</th>
                                    <th>OrderID</th>
                                    <th>Commission Earn</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php($i=1)
                                @foreach($dealercommission as $item)
                                <tr>
                                    <td>{{ $i++ }}</td>
                                    <td style="text-align: center">{{ $item->downline_user_id }}</td>

                                    <td style="text-align: center">{{ $item->downlineUserbane->username }}</td>

                                    <td style="text-align: center">{{ $item->order_id }}</td>

                                    <td style="text-align: center">{{ $item->commission_amount }}</td>

                                    <td style="text-align: center">
                                        {{ $item->updated_at }}           </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                        </div>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->
    </div>
</div>
<script>
  $(document).ready(function() {
        $('#walletrequest').DataTable({
            // Other DataTable options...
            "columnDefs": [
                {
                    "orderable": false, "targets": 2
                    } // Disable sorting for the third column (index 2)
            ]
        });
    });
    </script>
@endsection
