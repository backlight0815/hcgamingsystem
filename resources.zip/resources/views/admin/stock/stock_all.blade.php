@extends('admin.admin_master')
@section('admin')
<head>
  <!-- Add the Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">

    <title>My Stock | HC Gaming Studio</title>
</head>
<style>

    .clearfix:after {
      content: "";
      display: table;
      clear: both;
    }

    .quantity {
    display: inline-block;
}

.quantity .input-text.qty {
    width: 60px;
    height: 39px;
    padding: 0 5px;
    text-align: center;
    background-color: transparent;
    border: 1px solid black;
}

.quantity .minus,
.quantity .plus {
    padding: 7px 10px 8px;
    height: 41px;
    background-color: #ffffff;
    border: 1px solid #efefef;
    cursor: pointer;
}

.quantity .minus {
    border-right: 0;
    font-size:24px;
}

.quantity .plus {
    border-left: 0;
    font-size:24px;

}

.quantity .minus:hover,
.quantity .plus:hover {
    background: #eeeeee;
}

.card{
    padding:5%;
}
#add-to-cart-btn,
    #buy-now-btn {
        font-size: 18px;
        margin-top: 15px;
        margin-left: 50px;
        width: 50%;
    }


#cart-total{
    font-size:16px;
    margin-bottom:20px;

}

.out-of-stock {
        background-color: red;
        color: white;
        padding: 5px;
        position: absolute;
        top: 0px;
        left:0px;
    }

    .message {
        color: #888; /* Use a light gray color */
        font-size: 24px; /* You can adjust the font size as needed */
    }

    </style>


<div class="page-content">
    <div class="container-fluid">
        @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
      @endif
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Product Catalogue</h4>



            </div>
        </div>
    </div>
    <div class="breadcrumb">
        @foreach ($breadcrumbData as $breadcrumb)
            <a href="{{ $breadcrumb['url'] }}">{{ $breadcrumb['label'] }}</a>
            @if (!$loop->last)
                <span> / </span>
            @endif
        @endforeach
    </div>

    <div id="cart-total" style="text-align: right;">
        <a href="{{ route('cart.summary') }}" style="display: inline-block;">
            <i class="fa fa-shopping-cart"></i> View items in cart
        </a>
        ({{ session('cartTotal', 0) }})
    </div>
    <div class="container">
        <div class="row">
            @php
            $allOutOfStock = true; // Initialize the flag as true
        @endphp
            @if ($product->isEmpty())
            <div class="card" style="text-align:center">
                <div class="col-md-12 message">
                    <h5 class="message">Waiting for admin to upload their product, Once uploaded, the product will be released.</h5>
                </div>
            </div>
        @else
            @foreach($product as $item)
            @if ($item->product_stock > 0) <!-- Add this condition to check if the product is in stock -->
            @php
            $allOutOfStock = false; // If any product is in stock, set the flag to false
        @endphp
<div class="col-md-4">
    <div class="card">
        <a class="card" href="{{ url('product_details',$item->id) }}">

        <img src="{{ $item->product_image }}" alt="Product_Image" height="250px" width="250px">
        @if ($item->product_stock <= 0)

        <div class="out-of-stock">Out of Stock</div>
        @endif

    </a>

        <div class="card-body">
          <h5 style="font-size:14px">{{ $item->product_name }}</h5>
          @php
          $role_id = Auth::user()->role_id; // Assuming you have access to the user's role_id
          $priceToShow = $role_id == 700 && $item->customer_price ? $item->customer_price : $item->product_price;

      @endphp

        @if ($role_id == 350 || $role_id == 700)
                                <small>Price: RM {{ $priceToShow }}</small>
                            @endif

<small style="float:right;font-size:10px">

            @if ($item['productcategory'] && !$item['productcategory']->trashed())
            {{ $item['productcategory']['product_category'] }}
        @else
            {{-- Category Not Available --}}
        @endif

    </small>
    <br>
    <!-- Check if the user relationship exists -->
    @if ($item->user)
        <smalll>Seller: {{ $item->user->username }}</small>
    @else
        <p>Dealer User: Unknown</p> <!-- Display a message indicating the user is unknown -->
    @endif
        </div>
        <form action="{{ route('cart.add') }}" method="POST" id="buynow">
            @csrf
            <input type="hidden" name="submission_type" class="submission-type" value="buy-now-details">
            <input type="hidden" name="product_id" value="{{ $item->id }}">
            Quantity
            <div class="quantity">
                <input type="button" value="-" class="minus" data-product-id="{{ $item->id }}">
                <input type="number" step="1" min="1" max="" name="quantity" value="1" title="Qty" class="input-text qty" id="quantity_{{ $item->id }}" data-stock="{{ $item->product_stock }}">
                <input type="button" value="+" class="plus" data-product-id="{{ $item->id }}">
            </div>
            @if ($item->product_stock <= 0)
                <button type="submit" id="add-to-cart-btn" class="btn btn-warning btn-rounded waves-effect waves-light" disabled>Out of Stock</button>
                <input type="hidden" name="redirect" value="summary">
                <button type="button" id="buy-now-btn" class="btn btn-secondary btn-rounded waves-effect waves-light mt-2" style="margin-left: 65px; width: 130px" disabled>Out Of Stock</button>
            @else
                <button type="submit" id="add-to-cart-btn" class="btn btn-warning btn-rounded waves-effect waves-light add-to-cart-btn" style="margin-left: 70px;">Add to Cart</button>
                <input type="hidden" name="redirect" value="summary">
               <button type="button" id="buy-now-btn" class="btn btn-secondary btn-rounded waves-effect waves-light mt-3 buy-now-btn" style="width: 180px;">Buy Now</button>

                {{-- <button type="button" id="buy-now-btn" class="btn btn-secondary btn-rounded waves-effect waves-light mt-3 buy-now-btn" style="width: 180px;">Buy Now</button> --}}
            @endif
        </form>

</div>
</div>
@endif <!-- End of the condition to check if the product is in stock -->

            @endforeach
            @if ($allOutOfStock && count($product) > 0)
            <div class="card" style="text-align:center">
                <div class="col-md-12 message">
                    <h5 class="message">Waiting for admin to upload their product, Once uploaded, the product will be released.</h5>
                </div>
            </div>
        @endif
            @endif
        </div>
    </div>
</div>


    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>

$(document).ready(function() {

        $('.plus').click(function() {
            var productId = $(this).data('product-id');
            var quantity = parseInt($('#quantity_' + productId).val());
            $('#quantity_' + productId).val(quantity + 1);
        });

        $('.minus').click(function() {
            var productId = $(this).data('product-id');
            var quantity = parseInt($('#quantity_' + productId).val());
            if (quantity > 1) {
                $('#quantity_' + productId).val(quantity - 1);
            }
        });
    });
    $(document).ready(function() {
  function updateCartTotal() {
    $.get('/cart-total', function(data) {
      $('#cart-total').text(data.total);
    });
  }

  // Call this function whenever an item is added, updated, or removed from the cart
  updateCartTotal();
});
$(document).ready(function() {
    var formSubmitted = false;

    $(document).on('click', '.buy-now-btn, .add-to-cart-btn', function(event) {
        console.log('Button clicked'); // Debug statement

        if (formSubmitted) {
            event.preventDefault();
            console.log('Form already submitted'); // Debug statement
            return false;
        }

        var button = $(this);
        var form = button.closest('form'); // Find the closest form element
        var productId = form.find('.product-id').val(); // Get the product ID from the form
        button.prop('disabled', true).text('Processing...');

        if (button.hasClass('buy-now-btn')) {
            form.find('.submission-type').val('buy-now-details');
            console.log('Buy Now clicked'); // Debug statement
        } else if (button.hasClass('add-to-cart-btn')) {
            form.find('.submission-type').val('add-to-cart');
            console.log('Add to Cart clicked'); // Debug statement
        }

        setTimeout(function() {
            formSubmitted = true;
            form.submit(); // Submit the correct form
        }, 500);
    });
});
</script>

@endsection
