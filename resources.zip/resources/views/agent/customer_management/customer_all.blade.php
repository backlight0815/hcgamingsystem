@extends('admin.admin_master')
@section('admin')
<head>
      <!-- Add the Bootstrap CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">

</head>
    <style>
.empty-cart-btn {
        background-color: black;
        color: white;
        float: right;
        margin-right:15px;
    }

    @media screen and (max-width: 768px) {
     .table-responsive {
         overflow-x: auto;
     }
 }
 .table-container {
        overflow-x: auto; /* Enable horizontal scrolling */
        max-width: 100%; /* Ensure the container takes full width of the parent */
    }

    /* Ensure table cells don't wrap and add padding for better readability */
    #datatable th,
    #datatable td {
        white-space: nowrap;
        padding: 8px;
    }


        </style>
<title>Customer Management | HC Gaming Studio</title>

<div class="page-content">
    <div class="container-fluid">

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Customer Management</h4>
                <a href="#" class="btn btn-danger btn-rounded waves-effect waves-light empty-cart-btn">Invite New Customer</a>



            </div>
        </div>
    </div>
    <!-- end page title -->
    <div class="breadcrumb">
        @foreach ($breadcrumbData as $breadcrumb)
            <a href="{{ $breadcrumb['url'] }}">{{ $breadcrumb['label'] }}</a>
            @if (!$loop->last)
                <span> / </span>
            @endif
        @endforeach
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h4 class="card-title mb-2" > All Customer Data</h4>

                    <div class="row text-center " >
                        <div class="row">

                            <div class="col-md-4 col-sm-12 border border-dark pt-3 mb-3">
                                <h5 class="mb-0">{{ $CustomerCount }}</h5>
                            <p class="text-muted text-truncate">Total of Customer</p>
                        </div>
                        <div class="col-md-4 col-sm-12 border border-dark pt-3 mb-3">
                            <h5 class="mb-0">{{ $activeCustomer }}</h5>
                            <p class="text-muted text-truncate">No Active Customer</p>
                        </div>
                        <div class="col-md-4 col-sm-12 border border-dark pt-3 mb-3">
                            <h5 class="mb-0">{{ $inactiveCustomer }}</h5>
                            <p class="text-muted text-truncate">No Inactive Customer</p>
                        </div>


                    </div>

                    </div>


<div class="table-responsive">
                    <table id="datatable" class="table table-bordered" style="border-collapse: collapse; border-spacing: 0; width: 100%;">

                        <input type="hidden" id="dynamicReferralCode" value="{{ Auth::user()->customer_referral_code ?? '' }}">
                        <thead>
                        <tr>
                            <th>SI</th>
                            <th>Username</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Upline</th>
                            <th>Registered At</th>
                            <th>Status</th>

                        </tr>
                        </thead>



                        <tbody>
                            @php($i=1)
                            @foreach($customerUsers as $item)
                        <tr>
                            <td>{{ $i++ }}</td>
                            <td>{{ $item->agent->username }}</td>
                            <td>{{ $item->agent->name }}</td>

                            <td>{{ $item->agent->email }} </td>
                            <td>
                                @if ($item->agent->upline)
                                    {{ $item->agent->upline->username }}
                                @else
                                    HC Gaming Sdn Bhd
                                @endif
                            </td>
                            <td>{{$item->created_at}}</td>
                            @if($item->agent->status==1)
                            <td style="color:green"> Active </td>
                            @elseif($item->agent->status==0)
                            <td style="color:red"> Inactive </td>
                            @endif
                            {{-- <td>{{ $item->status }}</td> --}}


                        </tr>
    @endforeach
                        </tbody>
                    </table>

</div>












                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->

    </div> <!-- container-fluid -->
    </div>


    <!-- Modal -->
<!-- The modal for inviting a new member -->
<div class="modal fade" id="inviteModal" tabindex="-1" aria-labelledby="inviteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="inviteModalLabel">Invite New Customer</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <p>Share this link with the new customer:</p>
          <div class="input-group mb-3">
            <input type="text" class="form-control" id="registrationLink" readonly>
            <button class="btn btn-outline-secondary" type="button" id="copyLinkBtn">Copy Link</button>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
      $(document).ready(function() {
          // Function to get URL parameters by name
          function getURLParameter(name) {
              const urlParams = new URLSearchParams(window.location.search);
              return urlParams.get(name);
          }

          // Check if referral_code parameter exists in the URL
          const referralCodeParam = getURLParameter('referral_code');

          if (referralCodeParam) {
              // If referral_code parameter is present, pre-fill the referral code field with its value
              const referralCodeInput = document.getElementById('referral_code');
              referralCodeInput.value = referralCodeParam;

              // Disable the referral code field since it's pre-filled
              referralCodeInput.disabled = true;
          }

          // Show the modal when the "Invite New Member" button is clicked
          $('.empty-cart-btn').on('click', function() {
              // Open the modal
              $('#inviteModal').modal('show');

              // Get the dynamic referral code from the hidden input field
              const dynamicReferralCode = $('#dynamicReferralCode').val();

              // Display the dynamic referral code in the modal content
              $('#referralCodeModal').text(dynamicReferralCode);

              const registrationLink = 'http://127.0.0.1:8000/register?referral_code=' + encodeURIComponent(dynamicReferralCode);

              // Set the value of the input field to the registration link
              $('#registrationLink').val(registrationLink);

              // Hide the referral code field and label after copying the link
              $('#referralCodeField').hide();
              $('#referralCodeLabel').hide();
          });

          // Copy the link to the clipboard when the "Copy Link" button is clicked
          $('#copyLinkBtn').on('click', function() {
              // Select the text inside the input field
              $('#registrationLink').select();

              try {
                  // Copy the text to the clipboard
                  document.execCommand('copy');

                  // Optionally, show a success message to the user
                  alert('Link copied to clipboard!');

                  // Hide the referral code field and label after copying the link
                  $('#referralCodeField').hide();
                  $('#referralCodeLabel').hide();
              } catch (err) {
                  // If copying to clipboard fails, you can handle the error here
                  alert('Failed to copy link to clipboard. Please copy it manually.');

                  // Show the referral code field and label again in case of an error
                  $('#referralCodeField').show();
                  $('#referralCodeLabel').show();
              }
          });

          // Show the referral code field and label again if the user cancels the copy action
          $('#registrationLink').on('input', function() {
              $('#referralCodeField').show();
              $('#referralCodeLabel').show();
          });
      });
  </script>
@endsection
