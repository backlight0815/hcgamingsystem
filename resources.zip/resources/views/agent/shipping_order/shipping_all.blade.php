@extends('admin.admin_master')
@section('admin')
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.min.css">

    <!-- DataTables CSS -->
 <link rel="stylesheet" href="https://cdn.datatables.net/1.11.6/css/jquery.dataTables.min.css">

 <!-- jQuery -->
 <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.min.css">

 <!-- DataTables JS -->
 <script src="https://cdn.datatables.net/1.11.6/js/jquery.dataTables.min.js"></script>

  <!-- Add the Bootstrap CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">

<!-- Add the Bootstrap JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.min.js"></script>
 </head>

 <style>
 @media screen and (max-width: 768px) {
     .table-responsive {
         overflow-x: auto;
     }
 }
 </style>
 <title>My Shipping Order |HC Gaming</title>
<div class="page-content">
    <div class="container-fluid">
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0">My Shipping Orders</h4>
                </div>
            </div>
        </div>
        <!-- end page title -->
        <div class="breadcrumb">
            @foreach ($breadcrumbData as $breadcrumb)
                <a href="{{ $breadcrumb['url'] }}">{{ $breadcrumb['label'] }}</a>
                @if (!$loop->last)
                    <span> / </span>
                @endif
            @endforeach
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title mb-2"> My Shipping Order Data</h4>
                        <div class="row text-center " >
                            <div class="col-md-3 col-sm-6 border border-dark pt-3 mb-3">
                                <h5 class="mb-0">{{ $orderCount }}</h5>
                                <p class="text-muted text-truncate">Total Order</p>
                            </div>

                            <div class="col-md-3 col-sm-6 border border-dark pt-3 mb-3">
                                <h5 class="mb-0">{{ $ApproveCount }}</h5>
                                <p class="text-muted text-truncate">No Confirmed Order</p>
                            </div>
                            <div class="col-md-3 col-sm-6 border border-dark pt-3 mb-3">
                                <h5 class="mb-0">{{ $DelivertCount }}</h5>
                                <p class="text-muted text-truncate">No Delivery Order</p>
                            </div>
                            <div class="col-md-3 col-sm-6 border border-dark pt-3 mb-3">
                                <h5 class="mb-0">{{ $ConmpleteCount }}</h5>
                                <p class="text-muted text-truncate">No Complete Order</p>
                            </div>
                        </div>

<div class="table-responsive">
                    <table id="myshippingorder" class="table table-bordered" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                                <tr>
                                    <th>Order ID</th>
                                    <th>Grand Total</th>
                                    <th>Stocks</th>
                                    <th>Status</th>
                                    <th>Payment Proof</th>

                                    <th>Transaction Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php($i=1)
                                @foreach($shippingData as $item)
                                <tr>
                                    <td>{{ $item->id }}</td>
                                    <td>RM {{ $item->total_amount }}</td>
                                    <td>{{ $item->orderItems->sum('quantity') }}</td>
                                    @if($item->status==0)
                                    <td style="color:grey"> Processing </td>
                                    @elseif($item->status==1)
                                    <td style="color:orange"> Confirmed </td>
                                    @elseif($item->status==2)
                                    <td style="color:darkblue"> Delivery </td>
                                    @elseif($item->status==3)
                                    <td style="color:green"> Completed </td>
                                    @elseif($item->status==-1)
                                    <td style="color:red"> Rejected </td>

                                    @endif
                                    <td>
                                        <a href="{{ asset($item->payment_proof) }}" data-lightbox="image" data-title="Payment Proof">
                                            <img src="{{ asset($item->payment_proof) }}" style="width: 120px; height: 120px;" alt="Payment Proof">
                                        </a>
                                    </td>
                                    <td>{{ $item->created_at }}</td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->
    </div>
</div>
<script>
    $(document).ready(function() {
          $('#myshippingorder').DataTable({
              // Other DataTable options...
            "columnDefs": [
            { "orderable": false, "targets": [1, 4] } // Disable sorting for columns 3 (index 2) and 5 (index 6)
        ]
          });
      });
      </script>
@endsection
