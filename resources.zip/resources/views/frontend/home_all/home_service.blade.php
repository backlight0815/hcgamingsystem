@php
        $services = App\Models\Service::latest()->get();
@endphp
<style>
.description{
    font-size:16px;
    font-family:'Times New Roman', Times, serif;
    color:black;
}
    </style>


<section class="services">
    <div class="container">
        <div class="services__title__wrap">
            <div class="row align-items-center justify-content-between">
                <div class="col-xl-5 col-lg-6 col-md-8">
                    <div class="section__title">
                        <span class="sub-title">02 - My Services</span>
                        <h6 class="description" style="colro:black">I am currently APU student and working on website development aspects and will also serve the teenager for the gaming services and changing money services aspects.</h6>
                    </div>
                </div>

                <div class="col-xl-5 col-lg-6 col-md-4">
                    <div class="services__arrow"></div>
                </div>
            </div>
        </div>

        <div class="row gx-0 services__active">
            @foreach($services as $item)


            <div class="col-xl-3">

                <div class="services__item">

                    <div class="services__thumb">
                        <a href="services-details.html"><img src="assets/img/images/services_img01.jpg" alt=""></a>
                    </div>
                    <div class="services__content">
                        <div class="services__icon">
                             <img class="light" src="{{ asset("frontend/assets/img/icons/services_icon01.png") }}">
                             <img class="dark" src="{{ asset("frontend/assets/img/icons/services_icon01.png") }}">

                        </div>

                        <h3 class="title"><a href="services-details.html">{{ $item->service_title }}</a></h3>
                        <p class="services__list">
                            {{-- {!! $item->short_description !!} --}}

                        </p>
                        <a href="{{ route('service.details',$item->id) }}" class="btn border-btn">Read more</a>
                    </div>
                </div>

            </div>
            @endforeach

        </div>

    </div>
</section>
